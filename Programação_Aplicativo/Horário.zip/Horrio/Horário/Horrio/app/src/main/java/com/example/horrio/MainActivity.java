package com.example.horrio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText h1, m1, h2, m2;
    TextView sh, sm;
    Button soma, subtrai, reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        h1 = findViewById(R.id.h1);
        m1 = findViewById(R.id.m1);
        h2 = findViewById(R.id.h2);
        m2 = findViewById(R.id.m2);
        sh = findViewById(R.id.sh);
        sm = findViewById(R.id.sm);
        soma = findViewById(R.id.soma);
        subtrai = findViewById(R.id.subtrai);
        reset = findViewById(R.id.reset);
    }

    public void controle_subtracao() {
        int controle_hora;
        int controle_minuto;
        int e = Integer.parseInt(sh.getText().toString());
        int f = Integer.parseInt(sm.getText().toString());

        while (f < 0){
            controle_hora = e -1;
            controle_minuto= f +60;
            sh.setText(controle_hora+"");
            sm.setText(controle_minuto+"");
        }
    }

    public void subtrai(View subtrai){
        controle_subtracao();
        int conta_min;
        int conta_hora;
        int a = Integer.parseInt(m1.getText().toString());
        int b = Integer.parseInt(m2.getText().toString());
        int c = Integer.parseInt(h1.getText().toString());
        int d = Integer.parseInt(h2.getText().toString());

        if(subtrai.isClickable()){
            conta_min = a - b;
            conta_hora = c - d;
            sh.setText(conta_hora+"");
            sm.setText(conta_min+"");
        }
    }

    public void soma(View soma){
        int conta_min;
        int conta_hora;
        int a = Integer.parseInt(m1.getText().toString());
        int b = Integer.parseInt(m2.getText().toString());
        int c = Integer.parseInt(h1.getText().toString());
        int d = Integer.parseInt(h2.getText().toString());

        if(subtrai.isClickable()){
            conta_min = a + b;
            conta_hora = c + d;
            sh.setText(conta_hora+"");
            sm.setText(conta_min+"");
        }
    }
}